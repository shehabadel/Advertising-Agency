# Line Hover Styles for Links

A couple of simple & subtle line hover animations for links using CSS only.

![Image](https://tympanus.net/codrops/wp-content/uploads/2021/02/LineHover_featured.jpg)

[Article on Codrops](https://tympanus.net/codrops/?p=53312)

[Demo](http://tympanus.net/Development/LineHoverStyles/)


## Misc

Follow Codrops: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/codrops), [GitHub](https://github.com/codrops), [Instagram](https://www.instagram.com/codropsss/)

## License
[MIT](LICENSE)

Made with :blue_heart: by [Codrops](http://www.codrops.com)





